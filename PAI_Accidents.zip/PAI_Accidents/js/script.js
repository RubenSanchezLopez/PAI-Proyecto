// Declaració de variables globals
let obj = [];
// Fi de la declaració de variables globals

/********************************************************************************/
/* Funció readSingleFile(e)                                                     */
/* Funció que permet que l'usuari recuperi un arxiu del seu disc dur            */
/********************************************************************************/

function readSingleFile(e) {
  var file = e.target.files[0];
  if (!file) {
    return;
  }

  let reader = new FileReader();
  reader.onload = function (e) {
    let contents = e.target.result;
    generaObj(contents);
  };
  reader.readAsText(file);
}

/********************************************************************************/
/* Funció generaObj(contents)                                                   */
/* Converteix el CSV en un objecte usable                                       */
/********************************************************************************/

function generaObj(contents) {
  const json = contents.split("\r");
  const fi = json.length;

  let t = json[1].split(",");
  document.getElementById("any").innerHTML =
    "Any: " + t[9].replace(/['"]+/g, "");

  for (let i = 1; i < fi - 1; i++) {
    let taula = json[i].split(",");

    obj[i - 1] = {};

    if (taula[4][0] === '"') {
      obj[i - 1].diaSet = taula[9];
      obj[i - 1].mes = parseInt(taula[11]);
      obj[i - 1].nomMes = taula[12];
      obj[i - 1].diaMes = parseInt(taula[13]);
      obj[i - 1].hora = parseInt(taula[14]);
      obj[i - 1].descAcc = taula[15];
      obj[i - 1].districte = taula[2];
      obj[i - 1].nDist = parseInt(taula[1]);
      obj[i - 1].barri = taula[4] + "," + taula[5];
    } else {
      obj[i - 1].diaSet = taula[8];
      obj[i - 1].mes = parseInt(taula[10]);
      obj[i - 1].nomMes = taula[11];
      obj[i - 1].diaMes = parseInt(taula[12]);
      obj[i - 1].hora = parseInt(taula[13]);
      obj[i - 1].descAcc = taula[14];
      obj[i - 1].districte = taula[2];
      obj[i - 1].nDist = parseInt(taula[1]);
      obj[i - 1].barri = taula[4];
    }
  }

  // 🔥 ESTA ES LA LÍNEA CLAVE QUE FALTABA 🔥
  window.dades = obj;

  return obj;
}

// Event per llegir el fitxer quan se selecciona
document
  .getElementById("file-input")
  .addEventListener("change", readSingleFile, false);

/********************************************************************************/
/* Funció creaFormulari()                                                       */
/********************************************************************************/

function creaFormulari() {
  let text = document.getElementById("resultats");
  text.innerHTML = "";

  let f = document.createElement("form");
  f.name = "formulari";

  let districtes = [];
  districtes[0] = "Altres";

  for (let i = 1; i < 11; i++) {
    let trobat = obj.find((e) => e.nDist === i);
    districtes[i] = trobat ? trobat.districte : "Districte " + i;
  }

  let sel = document.createElement("select");
  sel.name = "districtes";
  sel.id = "districtes";

  for (let i = 0; i < 11; i++) {
    let op = document.createElement("option");
    op.textContent = districtes[i];
    op.value = i;
    sel.appendChild(op);
  }

  f.appendChild(sel);
  text.appendChild(f);
}
