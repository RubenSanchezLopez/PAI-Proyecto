document.addEventListener("DOMContentLoaded", function () {

    document.getElementById("exer01").onclick = function (e) {
        e.preventDefault();
        exercici01();
    };

    document.getElementById("exer02").onclick = function (e) {
        e.preventDefault();
        exercici02();
    };

    document.getElementById("exer03").onclick = function (e) {
        e.preventDefault();
        exercici03();
    };

    document.getElementById("exer04").onclick = function (e) {
        e.preventDefault();
        exercici04();
    };

});


function netejaResultats() {
    document.getElementById("resultats").innerHTML = "";
}


function comprovaDades() {
    if (!window.dades || dades.length === 0) {
        document.getElementById("resultats").textContent =
            "Primer cal seleccionar l'arxiu de dades";
        return false;
    }
    return true;
}


/* EXERCICI 01 */
function exercici01() {
    netejaResultats();
    if (!comprovaDades()) return;

    document.getElementById("resultats").innerHTML =
        "<h2>Nombre total d'accidents</h2><p>" + dades.length + "</p>";
}


/* EXERCICI 02 */
function exercici02() {
    netejaResultats();
    if (!comprovaDades()) return;

    let comptador = {};
    dades.forEach(a => {
        comptador[a.diaSet] = (comptador[a.diaSet] || 0) + 1;
    });

    let maxDia = "";
    let max = 0;

    for (let d in comptador) {
        if (comptador[d] > max) {
            max = comptador[d];
            maxDia = d;
        }
    }

    document.getElementById("resultats").innerHTML =
        "<h2>Dia setmana amb més accidents</h2><p>" + maxDia + "</p>";
}


/* EXERCICI 03 */
function exercici03() {
    netejaResultats();
    if (!comprovaDades()) return;

    let comptador = {};
    dades.forEach(a => {
        comptador[a.nDist] = (comptador[a.nDist] || 0) + 1;
    });

    let html = "<h2>Accidents per districtes</h2><ul>";
    for (let d in comptador) {
        html += "<li>Districte " + d + ": " + comptador[d] + "</li>";
    }
    html += "</ul>";

    document.getElementById("resultats").innerHTML = html;
}


/* EXERCICI 04 */
function exercici04() {
    netejaResultats();
    if (!comprovaDades()) return;

    let html = "<h2>Dades per a un districte</h2>";
    html += "<select id='selDist'>";
    html += "<option value=''>Selecciona</option>";

    for (let i = 1; i <= 10; i++) {
        html += `<option value="${i}">Districte ${i}</option>`;
    }

    html += "</select><p id='resDist'></p>";

    document.getElementById("resultats").innerHTML = html;

    document.getElementById("selDist").onchange = function () {
        let d = parseInt(this.value);
        let count = dades.filter(a => a.nDist === d).length;

        document.getElementById("resDist").textContent =
            isNaN(d) ? "" : "Accidents: " + count;
    };
}
