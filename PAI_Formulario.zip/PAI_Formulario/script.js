// =====================================
// VARIABLES
// =====================================

const nombreInput = document.getElementById("nombre");
const edadSelect = document.getElementById("edad");
const cpInput = document.getElementById("cp");
const emailInput = document.getElementById("email");
const passInput = document.getElementById("pass");
const pass2Input = document.getElementById("pass2");
const privacidadCheck = document.getElementById("privacidad");

const errorNombre = document.getElementById("errorNombre");
const errorEdad = document.getElementById("errorEdad");
const errorCP = document.getElementById("errorCP");
const errorEmail = document.getElementById("errorEmail");
const errorPass = document.getElementById("errorPass");
const errorPass2 = document.getElementById("errorPass2");
const errorPrivacidad = document.getElementById("errorPrivacidad");

const borrarBtn = document.getElementById("borrar");
const enviarBtn = document.getElementById("enviar");
const resultadoDiv = document.getElementById("resultado");

const verPass = document.getElementById("verPass");
const verPass2 = document.getElementById("verPass2");


// =====================================
// 1.1 NOMBRE Y APELLIDOS
// =====================================

nombreInput.addEventListener("blur", function () {
    let texto = nombreInput.value.trim();

    if (texto === "") {
        errorNombre.textContent = "El nombre no puede estar vacío";
        return;
    }

    let palabras = texto.split(" ");
    let resultado = "";

    for (let i = 0; i < palabras.length; i++) {
        if (palabras[i] !== "") {
            resultado += palabras[i][0].toUpperCase() +
                         palabras[i].substring(1).toLowerCase() + " ";
        }
    }

    nombreInput.value = resultado.trim();
    errorNombre.textContent = "";
});


// =====================================
// 1.2 RANGO DE EDAD (CORREGIDO)
// =====================================

// Al salir del select
edadSelect.addEventListener("blur", comprobarEdad);
// Al cambiar opción
edadSelect.addEventListener("change", comprobarEdad);

function comprobarEdad() {
    if (edadSelect.value === "") {
        errorEdad.textContent = "Debes seleccionar un rango de edad";
    } else {
        errorEdad.textContent = "";
    }
}


// =====================================
// 1.3 CÓDIGO POSTAL
// =====================================

cpInput.addEventListener("blur", function () {
    let cp = cpInput.value;

    if (cp.length !== 5) {
        errorCP.textContent = "El código postal debe tener 5 dígitos";
        return;
    }

    for (let i = 0; i < cp.length; i++) {
        if (cp[i] < "0" || cp[i] > "9") {
            errorCP.textContent = "El código postal solo puede tener números";
            return;
        }
    }

    errorCP.textContent = "";
});


// =====================================
// 1.4 EMAIL
// =====================================

emailInput.addEventListener("blur", function () {
    let email = emailInput.value;
    let arroba = false;
    let puntoDespues = false;

    for (let i = 0; i < email.length; i++) {
        if (email[i] === "@") {
            if (arroba) {
                errorEmail.textContent = "El email solo puede tener una @";
                return;
            }
            arroba = true;
        }
        if (arroba && email[i] === ".") {
            puntoDespues = true;
        }
    }

    if (!arroba || !puntoDespues) {
        errorEmail.textContent = "Email incorrecto";
        return;
    }

    errorEmail.textContent = "";
});


// =====================================
// 1.5 CONTRASEÑA
// =====================================

passInput.addEventListener("blur", function () {
    let pass = passInput.value;

    let mayus = false;
    let minus = false;
    let digitos = 0;
    let especial = false;
    let especiales = "!@#$%^&*()_+[]-={};:\\|,.<>/?";

    if (pass.length < 8) {
        errorPass.textContent = "Mínimo 8 caracteres";
        return;
    }

    for (let i = 0; i < pass.length; i++) {
        let c = pass[i];

        if (c >= "A" && c <= "Z") mayus = true;
        else if (c >= "a" && c <= "z") minus = true;
        else if (c >= "0" && c <= "9") digitos++;
        else if (especiales.includes(c)) especial = true;
    }

    if (!mayus || !minus || digitos < 2 || !especial) {
        errorPass.textContent = "Contraseña no válida";
        return;
    }

    errorPass.textContent = "";
});


// =====================================
// 1.6 CONFIRMAR CONTRASEÑA
// =====================================

pass2Input.addEventListener("blur", function () {
    if (pass2Input.value !== passInput.value) {
        errorPass2.textContent = "Las contraseñas no coinciden";
    } else {
        errorPass2.textContent = "";
    }
});


// =====================================
// VER CONTRASEÑA (CORREGIDO)
// =====================================

verPass.addEventListener("change", function () {
    passInput.type = verPass.checked ? "text" : "password";
});

verPass2.addEventListener("change", function () {
    pass2Input.type = verPass2.checked ? "text" : "password";
});


// =====================================
// 1.7 PRIVACIDAD
// =====================================

privacidadCheck.addEventListener("change", function () {
    if (!privacidadCheck.checked) {
        errorPrivacidad.textContent = "Debes aceptar la política";
    } else {
        errorPrivacidad.textContent = "";
    }
});


// =====================================
// 1.8 BOTÓN BORRAR
// =====================================

borrarBtn.addEventListener("click", function () {
    document.getElementById("formulario").reset();
    resultadoDiv.textContent = "";

    errorNombre.textContent = "";
    errorEdad.textContent = "";
    errorCP.textContent = "";
    errorEmail.textContent = "";
    errorPass.textContent = "";
    errorPass2.textContent = "";
    errorPrivacidad.textContent = "";
});


// =====================================
// 1.9 BOTÓN ENVIAR
// =====================================

enviarBtn.addEventListener("click", function () {

    comprobarEdad();

    if (
        errorNombre.textContent === "" &&
        errorEdad.textContent === "" &&
        errorCP.textContent === "" &&
        errorEmail.textContent === "" &&
        errorPass.textContent === "" &&
        errorPass2.textContent === "" &&
        privacidadCheck.checked
    ) {
        resultadoDiv.innerHTML =
            "<h3>Formulario enviado correctamente</h3>" +
            "<p><strong>Nombre:</strong> " + nombreInput.value + "</p>" +
            "<p><strong>Edad:</strong> " + edadSelect.value + "</p>" +
            "<p><strong>Código postal:</strong> " + cpInput.value + "</p>" +
            "<p><strong>Email:</strong> " + emailInput.value + "</p>";
    } else {
        alert("Hay errores en el formulario");
    }
});
